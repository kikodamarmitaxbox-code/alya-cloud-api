# Astra - Assistente IA Leve v2.0

Este projeto cria uma assistente pessoal de IA moderna e segura que roda no navegador. O computador fica leve porque a IA roda por API.

## 🚀 Recursos

- **Múltiplas APIs gratuitas**: OpenRouter e Gemini
- **Segurança avançada**: Hash de senhas com bcrypt, rate limiting, CORS configurável
- **Sistema de autenticação**: Login por usuário/senha ou senha única
- **Personalidades**: Equilibrada, Direta, Amiga, Técnica, Jarvis
- **Modos de operação**: Normal, Estudo, Criativo, Código, Rápido
- **Multi-conversas**: Gerencie várias conversas simultâneas
- **Busca no histórico**: Encontre mensagens anteriores facilmente
- **Exportação versátil**: TXT, JSON, Markdown, PDF
- **Tema claro/escuro**: Alternância de temas
- **Sistema WhatsApp**: Fila de aprovação para mensagens
- **Modo Dev**: Autoconfiguração da IA
- **Persistência no servidor**: Histórico salvo automaticamente
- **Logging estruturado**: Logs profissionais com Winston
- **Backup rotativo**: Backups automáticos com rotação

## 📋 Pré-requisitos

- Node.js 18 ou mais recente
- npm ou yarn

## 🛠️ Como usar

1. Clone ou baixe este projeto
2. Instale as dependências:

```bash
npm install
```

3. Configure o arquivo `.env`:

```bash
cp .env.example .env
```

4. Abra o arquivo `.env` e coloque sua chave gratuita:

```env
# Opção 1: OpenRouter
AI_PROVIDER=openrouter
OPENROUTER_API_KEY=sua_chave_aqui
OPENROUTER_MODEL=openrouter/free
MAX_TOKENS=500

# Opção 2: Gemini
# AI_PROVIDER=gemini
# GEMINI_API_KEY=sua_chave_aqui
# GEMINI_MODEL=gemini-2.5-flash
```

5. Inicie o servidor:

```bash
npm start
```

6. Abra no navegador:

```text
http://localhost:3000
```

## 🌐 Rodar online

Você pode publicar a Astra em serviços de hospedagem como Render, Railway ou Vercel.

### Render

1. Coloque a pasta do projeto em um repositório do GitHub
2. No Render, crie um Web Service
3. Use estes comandos:

```text
Build Command: npm install
Start Command: npm start
```

4. Adicione as mesmas variáveis do seu `.env` na área de Environment Variables
5. Depois do deploy, a Astra vai abrir em uma URL como:

```text
https://seu-projeto.onrender.com
```

## 🔐 Login para amigos

Para pedir usuário e senha antes de entrar, coloque no `.env`:

```env
FRIEND_USERS=pedro:astra123,amigo:1234
```

Troque os usuários e senhas como quiser.

Quando publicar online, coloque `FRIEND_USERS` também nas Environment Variables da hospedagem.

Se preferir uma senha única sem usuário, remova `FRIEND_USERS` e use:

```env
SITE_PASSWORD=astra123
```

## 🔗 Link fixo

Para ter um link fixo, publique em uma hospedagem como Render. Depois você pode usar a URL grátis do Render ou conectar um domínio próprio.

Exemplos:

```text
https://sua-astra.onrender.com
https://minhaastra.com
```

## 🤖 APIs gratuitas

- **OpenRouter**: use `AI_PROVIDER=openrouter` e `OPENROUTER_MODEL=openrouter/free`
- **Gemini**: use `AI_PROVIDER=gemini` e `GEMINI_MODEL=gemini-2.5-flash`

As duas opções gratuitas têm limites e podem mudar com o tempo.

Se quiser respostas mais curtas e rápidas, diminua `MAX_TOKENS` no arquivo `.env`.

## 🔧 Troubleshooting

### Servidor não inicia
- Verifique se o Node.js 18+ está instalado: `node --version`
- Verifique se as dependências foram instaladas: `npm install`
- Verifique se a porta 3000 não está em uso

### Erro de autenticação
- Verifique se as variáveis de ambiente estão configuradas corretamente
- Limpe os cookies do navegador
- Verifique os logs em `nova-data/logs/`

### API não responde
- Verifique se a chave da API está correta
- Verifique se você não excedeu o limite da API gratuita
- Use a rota `/health` para verificar o status das dependências

### Erro de CORS
- Configure `CORS_ORIGIN` no `.env` com o domínio correto
- Verifique se o middleware CORS está funcionando

### Rate limit atingido
- Aguarde 15 minutos para o limite resetar
- Ajuste as configurações de rate limit em `lib/rateLimit.js`

## 📚 FAQ

**P: Posso usar minha própria chave de API?**
R: Sim, configure `OPENROUTER_API_KEY` ou `GEMINI_API_KEY` no `.env`.

**P: A Astra funciona offline?**
R: Não, ela precisa de conexão com a internet para acessar as APIs de IA.

**P: Meus dados são seguros?**
R: Sim, as senhas são hasheadas com bcrypt e não há armazenamento de dados sensíveis.

**P: Posso hospedar gratuitamente?**
R: Sim, serviços como Render oferecem hospedagem gratuita para projetos Node.js.

**P: Como faço backup das minhas conversas?**
R: Use o botão de exportação ou os arquivos em `nova-data/history/`.

**P: Posso integrar com WhatsApp?**
R: Sim, há um sistema de aprovação de mensagens pronto para integração.

## 🤝 Contribuindo

Contribuições são bem-vindas! Por favor:

1. Fork o projeto
2. Crie uma branch para sua feature (`git checkout -b feature/MinhaFeature`)
3. Commit suas mudanças (`git commit -m 'Adiciona MinhaFeature'`)
4. Push para a branch (`git push origin feature/MinhaFeature`)
5. Abra um Pull Request

## 📝 Estrutura do projeto

```
ia nova/
├── lib/                 # Módulos do servidor
│   ├── auth.js         # Autenticação e autorização
│   ├── chat.js         # Integração com APIs de IA
│   ├── whatsapp.js     # Sistema WhatsApp
│   ├── profile.js      # Gerenciamento de perfil
│   ├── history.js      # Persistência de histórico
│   ├── rateLimit.js    # Rate limiting
│   ├── logger.js       # Logging estruturado
│   └── utils.js        # Utilitários
├── public/             # Arquivos estáticos
│   ├── index.html      # Interface principal
│   ├── styles.css      # Estilos
│   └── app.js          # Lógica do frontend
├── nova-data/          # Dados da aplicação
│   ├── history/        # Histórico de conversas
│   ├── backups/        # Backups automáticos
│   └── logs/           # Logs do servidor
├── .env                # Variáveis de ambiente
├── .env.example        # Exemplo de configuração
├── package.json        # Dependências
├── render.yaml         # Configuração do Render
└── server.js           # Servidor principal
```

## 🔒 Segurança

- Senhas hasheadas com bcrypt
- Rate limiting por IP
- CORS configurável
- Cookies com flag HttpOnly e Secure (HTTPS)
- Validação de entrada
- Proteção contra injeção de código
- Logs de auditoria

## 📄 Licença

Este projeto é open source e está disponível sob a licença MIT.

## 🆘 Suporte

Se encontrar problemas ou tiver dúvidas:
- Abra uma issue no GitHub
- Verifique a seção de Troubleshooting
- Consulte os logs em `nova-data/logs/`
