const http = require('http');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const logger = require('./lib/logger');
const { isAuthenticated, hasSitePassword, validateLogin, setAuthCookie, clearAuthCookie, readSiteUsers } = require('./lib/auth');
const { askAssistant, askAssistantStream, normalizeSettings } = require('./lib/chat');
const { handleWhatsappReceive, handleWhatsappApprove, handleWhatsappCancel, getWhatsappQueue, readWhatsappLog } = require('./lib/whatsapp');
const { UserFacingError, sendJson, sendText, loadLocalEnv, getSafeRequest } = require('./lib/utils');
const { readDevProfile, handleApplyProfile, rotateBackups } = require('./lib/profile');
const { saveConversationHistory, loadConversationHistory, deleteConversationHistory, listAllConversations } = require('./lib/history');
const { listFiles, readFile, writeFile, executeCommand, installDependency, createBackup, restoreBackup } = require('./lib/fileOps');
const { apiLimiter, authLimiter } = require('./lib/rateLimit');

const root = __dirname;
const publicDir = path.join(root, 'public');
const port = Number(process.env.PORT || 3000);

loadLocalEnv();

const mimeTypes = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

const corsMiddleware = cors({
  origin: process.env.CORS_ORIGIN || '*',
  credentials: true
});

const server = http.createServer(async (req, res) => {
  try {
    corsMiddleware(req, res, () => {});
    
    const url = new URL(req.url, `http://${req.headers.host}`);

    if (req.method === 'POST' && url.pathname === '/api/chat') {
      if (!apiLimiter.check(req, res)) return;
      if (!requireAuth(req, res)) return;
      await handleChat(req, res);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/chat-stream') {
      if (!apiLimiter.check(req, res)) return;
      if (!requireAuth(req, res)) return;
      await handleChatStream(req, res);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/auth/status') {
      const users = readSiteUsers();
      sendJson(res, 200, {
        protected: hasSitePassword(),
        authenticated: isAuthenticated(req),
        loginMode: users.length > 0 ? 'users' : hasSitePassword() ? 'password' : 'none'
      });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/auth/login') {
      if (!authLimiter.check(req, res)) return;
      await handleLogin(req, res);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
      clearAuthCookie(res);
      sendJson(res, 200, { ok: true });
      return;
    }

    if (req.method === 'GET' && url.pathname === '/health') {
      await handleHealthCheck(req, res);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/dev/profile') {
      if (!requireAuth(req, res)) return;
      sendJson(res, 200, readDevProfile());
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/apply-profile') {
      if (!requireAuth(req, res)) return;
      const result = await handleApplyProfile(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/whatsapp/receive') {
      await handleWhatsappReceiveRoute(req, res);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/whatsapp/queue') {
      if (!requireAuth(req, res)) return;
      sendJson(res, 200, { queue: getWhatsappQueue() });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/whatsapp/approve') {
      if (!requireAuth(req, res)) return;
      const result = await handleWhatsappApproveRoute(req, res);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/whatsapp/cancel') {
      if (!requireAuth(req, res)) return;
      const result = await handleWhatsappCancelRoute(req, res);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/whatsapp/log') {
      if (!requireAuth(req, res)) return;
      sendJson(res, 200, { log: readWhatsappLog() });
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/history/save') {
      if (!requireAuth(req, res)) return;
      const result = await handleSaveHistory(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/history/load') {
      if (!requireAuth(req, res)) return;
      const conversationId = url.searchParams.get('conversationId');
      const result = loadConversationHistory(conversationId);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'DELETE' && url.pathname === '/api/history/delete') {
      if (!requireAuth(req, res)) return;
      const conversationId = url.searchParams.get('conversationId');
      const result = deleteConversationHistory(conversationId);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/history/list') {
      if (!requireAuth(req, res)) return;
      const result = listAllConversations();
      sendJson(res, 200, result);
      return;
    }

    // Dev mode file operations
    if (req.method === 'GET' && url.pathname === '/api/dev/files') {
      if (!requireAuth(req, res)) return;
      const dirPath = url.searchParams.get('path') || root;
      const result = listFiles(dirPath);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'GET' && url.pathname === '/api/dev/file') {
      if (!requireAuth(req, res)) return;
      const filePath = url.searchParams.get('path');
      const result = readFile(filePath);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/file') {
      if (!requireAuth(req, res)) return;
      const result = await handleWriteFile(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/command') {
      if (!requireAuth(req, res)) return;
      const result = await handleExecuteCommand(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/install') {
      if (!requireAuth(req, res)) return;
      const result = await handleInstallDependency(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/backup') {
      if (!requireAuth(req, res)) return;
      const result = await handleCreateBackup(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method === 'POST' && url.pathname === '/api/dev/restore') {
      if (!requireAuth(req, res)) return;
      const result = await handleRestoreBackup(req);
      sendJson(res, 200, result);
      return;
    }

    if (req.method !== 'GET') {
      sendJson(res, 405, { error: 'Metodo nao permitido.' });
      return;
    }

    serveStatic(url.pathname, res);
  } catch (error) {
    logger.error('Server error:', error);
    const message = error instanceof UserFacingError
      ? error.message
      : 'Algo deu errado no servidor local.';
    if (res.headersSent) {
      res.end(`\n${message}`);
      return;
    }
    sendJson(res, 500, { error: message });
  }
});

server.listen(port, '0.0.0.0', () => {
  logger.info(`Assistente pronto em http://localhost:${port}`);
  rotateBackups();
  
  setInterval(() => {
    rotateBackups();
  }, 24 * 60 * 60 * 1000);
});

function serveStatic(requestPath, res) {
  const safePath = requestPath === '/' ? '/index.html' : requestPath;
  const filePath = path.normalize(path.join(publicDir, safePath));

  if (!filePath.startsWith(publicDir)) {
    sendText(res, 403, 'Acesso negado.');
    return;
  }

  fs.readFile(filePath, (error, data) => {
    if (error) {
      sendText(res, 404, 'Arquivo nao encontrado.');
      return;
    }

    const ext = path.extname(filePath);
    res.writeHead(200, {
      'Content-Type': mimeTypes[ext] || 'application/octet-stream',
      'Cache-Control': 'no-store'
    });
    res.end(data);
  });
}

function requireAuth(req, res) {
  if (isAuthenticated(req)) return true;
  sendJson(res, 401, { error: 'Digite a senha para entrar na Astra.' });
  return false;
}

async function handleLogin(req, res) {
  loadLocalEnv(true);
  const body = await getSafeRequest(req);
  const users = readSiteUsers();

  if (users.length === 0 && !hasSitePassword()) {
    sendJson(res, 200, { ok: true, protected: false, loginMode: 'none' });
    return;
  }

  const result = await validateLogin(body.username, body.password);
  
  if (!result.success) {
    sendJson(res, 401, { error: result.error });
    return;
  }

  setAuthCookie(res, result.user);
  sendJson(res, 200, { 
    ok: true, 
    protected: true, 
    loginMode: users.length > 0 ? 'users' : 'password', 
    user: result.user 
  });
}

async function handleChat(req, res) {
  const { safeMessages, settings } = await getSafeRequest(req);
  const reply = await askAssistant(safeMessages, settings);
  sendJson(res, 200, { reply });
}

async function handleChatStream(req, res) {
  const { safeMessages, settings } = await getSafeRequest(req);
  await askAssistantStream(safeMessages, settings, res);
}

async function handleHealthCheck(req, res) {
  const health = {
    ok: true,
    name: 'Astra',
    version: '2.0.0',
    timestamp: new Date().toISOString(),
    dependencies: {
      openrouter: !!process.env.OPENROUTER_API_KEY,
      gemini: !!process.env.GEMINI_API_KEY
    }
  };
  
  sendJson(res, 200, health);
}

async function handleWhatsappReceiveRoute(req, res) {
  const body = await getSafeRequest(req);
  const result = await handleWhatsappReceive(body);
  sendJson(res, 200, result);
}

async function handleWhatsappApproveRoute(req, res) {
  const body = await getSafeRequest(req);
  const result = await handleWhatsappApprove(body.id, body.reply);
  sendJson(res, 200, result);
}

async function handleWhatsappCancelRoute(req, res) {
  const body = await getSafeRequest(req);
  const result = await handleWhatsappCancel(body.id);
  sendJson(res, 200, result);
}

async function handleSaveHistory(req) {
  const body = await getSafeRequest(req);
  const { conversationId, messages } = body;
  return saveConversationHistory(conversationId, messages);
}

async function handleWriteFile(req) {
  const body = await getSafeRequest(req);
  const { path: filePath, content, approved = false } = body;
  return writeFile(filePath, content, !approved);
}

async function handleExecuteCommand(req) {
  const body = await getSafeRequest(req);
  const { command, approved = false } = body;
  return executeCommand(command, !approved);
}

async function handleInstallDependency(req) {
  const body = await getSafeRequest(req);
  const { package: packageName, approved = false } = body;
  return installDependency(packageName);
}

async function handleCreateBackup(req) {
  const body = await getSafeRequest(req);
  const { path: filePath } = body;
  return createBackup(filePath);
}

async function handleRestoreBackup(req) {
  const body = await getSafeRequest(req);
  const { backupPath, originalPath } = body;
  return restoreBackup(backupPath, originalPath);
}

process.on('uncaughtException', (error) => {
  logger.error('Uncaught exception:', error);
});

process.on('unhandledRejection', (error) => {
  logger.error('Unhandled rejection:', error);
});
