const accessGate = document.querySelector("#accessGate");
const accessForm = document.querySelector("#accessForm");
const usernameField = document.querySelector("#usernameField");
const accessUsername = document.querySelector("#accessUsername");
const accessPassword = document.querySelector("#accessPassword");
const accessSubmit = document.querySelector("#accessSubmit");
const accessError = document.querySelector("#accessError");
const appShell = document.querySelector("#appShell");
const messagesEl = document.querySelector("#messages");
const form = document.querySelector("#chatForm");
const input = document.querySelector("#messageInput");
const sendButton = document.querySelector("#sendButton");
const clearButton = document.querySelector("#clearButton");
const personalitySelect = document.querySelector("#personalitySelect");
const memoryButton = document.querySelector("#memoryButton");
const exportButton = document.querySelector("#exportButton");
const memoryModal = document.querySelector("#memoryModal");
const memoryInput = document.querySelector("#memoryInput");
const closeMemoryButton = document.querySelector("#closeMemoryButton");
const saveMemoryButton = document.querySelector("#saveMemoryButton");
const devModeButton = document.querySelector("#devModeButton");
const devHistoryButton = document.querySelector("#devHistoryButton");
const fileApprovalModal = document.querySelector("#fileApprovalModal");
const filePreview = document.querySelector("#filePreview");
const applyFileEditButton = document.querySelector("#applyFileEditButton");
const cancelFileEditButton = document.querySelector("#cancelFileEditButton");
const modeButtons = Array.from(document.querySelectorAll(".mode-button"));

const storageKey = "nova-chat-history";
const settingsKey = "nova-settings";
const apiBase = window.location.protocol === "file:" ? "http://localhost:3000" : "";
let history = loadHistory();
let settings = loadSettings();
let pendingFileProfile = null;
let loginMode = "password";
let conversations = loadConversations();
let currentConversationId = conversations.length > 0 ? conversations[0].id : createNewConversation();

personalitySelect.value = settings.personality;
memoryInput.value = settings.memory;
syncModeUI();
syncDevModeUI();

if (history.length === 0) {
  history = [
    {
      role: "assistant",
      content: "Oi, eu sou a Astra. Posso te ajudar com ideias, estudos, textos e organizacao."
    }
  ];
}

boot();

accessForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  accessSubmit.disabled = true;
  accessError.textContent = "";

  try {
    const response = await fetch(`${apiBase}/api/auth/login`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        username: accessUsername.value,
        password: accessPassword.value
      })
    });
    const data = await response.json().catch(() => ({}));

    if (!response.ok || data.error) {
      throw new Error(data.error || "Nao consegui entrar agora.");
    }

    showApp();
  } catch (error) {
    accessError.textContent = error.message || "Senha incorreta.";
    accessPassword.select();
  } finally {
    accessSubmit.disabled = false;
  }
});

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const content = input.value.trim();
  if (!content) return;

  // Check for Dev commands first
  const devCommand = parseDevCommand(content);
  
  if (devCommand) {
    history.push({ role: "user", content });
    input.value = "";
    input.style.height = "auto";
    render();

    const assistantMessage = { role: "assistant", content: "" };
    history.push(assistantMessage);
    saveHistory();
    render();

    if (devCommand.action === 'listFiles' || devCommand.action === 'readFile') {
      // Read-only actions don't need approval
      const endpoint = devCommand.action === 'listFiles' ? '/api/dev/files' : '/api/dev/file';
      const param = devCommand.action === 'listFiles' ? 'path' : 'path';
      const url = `${apiBase}${endpoint}?${param}=${encodeURIComponent(devCommand.details.path || '')}`;
      
      try {
        const response = await fetch(url);
        const result = await response.json();
        
        if (result.ok) {
          if (devCommand.action === 'listFiles') {
            assistantMessage.content = `Arquivos encontrados:\n${result.files.map(f => `- ${f.type}: ${f.name}`).join('\n')}`;
          } else {
            assistantMessage.content = `Conteúdo do arquivo:\n\`\`\`\n${result.content}\n\`\`\``;
          }
          addDevHistory(devCommand.action, devCommand.details, 'success');
        } else {
          assistantMessage.content = `Erro: ${result.error}`;
          addDevHistory(devCommand.action, devCommand.details, 'error');
        }
      } catch (error) {
        assistantMessage.content = `Erro ao executar ação: ${error.message}`;
        addDevHistory(devCommand.action, devCommand.details, 'error');
      }
    } else {
      // Actions that may require approval
      const result = await executeDevAction(devCommand.action, devCommand.details);
      
      if (result === null) {
        // Action requires approval, waiting for user
        assistantMessage.content = "Aguardando aprovação do usuário...";
        return;
      }
      
      if (result.ok) {
        assistantMessage.content = "Ação executada com sucesso.";
      } else {
        assistantMessage.content = `Erro ao executar ação: ${result.error}`;
      }
    }
    
    saveHistory();
    render();
    return;
  }

  // Normal chat flow
  history.push({ role: "user", content });
  input.value = "";
  input.style.height = "auto";
  setBusy(true);
  render();

  const assistantMessage = { role: "assistant", content: "" };
  history.push(assistantMessage);
  saveHistory();
  render();

  try {
    const response = await fetch(`${apiBase}/api/chat-stream`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: history
          .filter((message) => message.role !== "system")
          .slice(0, -1),
        settings
      })
    });

    if (!response.ok) {
      const data = await response.json().catch(() => ({}));
      throw new Error(data.error || "Nao consegui falar com a API agora.");
    }

    await readStreamingReply(response, assistantMessage);
    assistantMessage.content = assistantMessage.content.trim() || "Nao recebi uma resposta da IA.";
    applyAssistantConfig(assistantMessage);
    prepareFileProfileEdit(assistantMessage);
    saveHistory();
    render();
  } catch (error) {
    assistantMessage.content = error.message || "Nao consegui responder agora.";
    saveHistory();
    render();
  } finally {
    setBusy(false);
    input.focus();
  }
});

input.addEventListener("input", () => {
  input.style.height = "auto";
  input.style.height = `${Math.min(input.scrollHeight, 140)}px`;
});

input.addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    form.requestSubmit();
  }
});

clearButton.addEventListener("click", () => {
  history = [
    {
      role: "assistant",
      content: "Conversa limpa. Me diga no que voce quer focar agora."
    }
  ];
  saveHistory();
  render();
  input.focus();
});

exportButton.addEventListener("click", exportConversation);

personalitySelect.addEventListener("change", () => {
  settings.personality = personalitySelect.value;
  saveSettings();
});

for (const button of modeButtons) {
  button.addEventListener("click", () => {
    settings.mode = button.dataset.mode || "normal";
    saveSettings();
    syncModeUI();
    input.focus();
  });
}

devModeButton.addEventListener("click", () => {
  settings.devMode = !settings.devMode;
  saveSettings();
  syncDevModeUI();

  history.push({
    role: "assistant",
    content: settings.devMode
      ? "Modo Dev ativado. Agora posso ajudar a configurar minha personalidade e memoria pelo chat."
      : "Modo Dev desativado. Voltei ao modo normal."
  });
  saveHistory();
  render();
});

memoryButton.addEventListener("click", () => {
  memoryInput.value = settings.memory;
  memoryModal.hidden = false;
  memoryInput.focus();
});

closeMemoryButton.addEventListener("click", closeMemory);
cancelFileEditButton.addEventListener("click", closeFileApproval);

saveMemoryButton.addEventListener("click", () => {
  settings.memory = memoryInput.value.trim();
  saveSettings();
  closeMemory();
});

memoryModal.addEventListener("click", (event) => {
  if (event.target === memoryModal) closeMemory();
});

fileApprovalModal.addEventListener("click", (event) => {
  if (event.target === fileApprovalModal) closeFileApproval();
});

applyFileEditButton.addEventListener("click", applyPendingFileProfile);

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !memoryModal.hidden) closeMemory();
  if (event.key === "Escape" && !fileApprovalModal.hidden) closeFileApproval();
});

messagesEl.addEventListener("click", async (event) => {
  const button = event.target.closest("[data-message-action]");
  if (!button) return;

  const index = Number(button.dataset.messageIndex);
  const message = history[index];
  if (!message?.content) return;

  if (button.dataset.messageAction === "copy") {
    await copyText(message.content);
    flashButton(button, "Copiado");
  }

  if (button.dataset.messageAction === "speak") {
    speakText(message.content);
  }
});

function render() {
  messagesEl.innerHTML = "";

  for (const [index, message] of history.entries()) {
    const article = document.createElement("article");
    article.className = `message ${message.role}`;
    if (message.role === "assistant" && !message.content) {
      article.classList.add("typing");
    }

    const label = document.createElement("span");
    label.className = "message-label";
    label.textContent = message.role === "user" ? "Voce" : "Astra";

    const content = document.createElement("div");
    content.className = "message-content";
    content.textContent = message.content || "Pensando...";

    article.append(label, content);

    if (message.role === "assistant" && message.content) {
      const actions = document.createElement("div");
      actions.className = "message-actions";

      const copyButton = document.createElement("button");
      copyButton.type = "button";
      copyButton.dataset.messageAction = "copy";
      copyButton.dataset.messageIndex = String(index);
      copyButton.title = "Copiar resposta";
      copyButton.setAttribute("aria-label", "Copiar resposta");
      copyButton.textContent = "Copiar";

      const speakButton = document.createElement("button");
      speakButton.type = "button";
      speakButton.dataset.messageAction = "speak";
      speakButton.dataset.messageIndex = String(index);
      speakButton.title = "Ouvir resposta";
      speakButton.setAttribute("aria-label", "Ouvir resposta");
      speakButton.textContent = "Ouvir";

      actions.append(copyButton, speakButton);
      article.append(actions);
    }

    messagesEl.append(article);
  }

  messagesEl.scrollTop = messagesEl.scrollHeight;
}

function setBusy(isBusy) {
  sendButton.disabled = isBusy;
  input.disabled = isBusy;
  
  const statusPill = document.querySelector('.status-pill');
  if (isBusy) {
    statusPill.textContent = 'digitando...';
    statusPill.style.color = 'var(--accent-warm)';
  } else {
    statusPill.textContent = 'pronta';
    statusPill.style.color = 'var(--accent)';
  }
}

async function readStreamingReply(response, assistantMessage) {
  if (!response.body) {
    const text = await response.text();
    assistantMessage.content = text;
    return;
  }

  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  let renderScheduled = false;

  function scheduleRender() {
    if (!renderScheduled) {
      renderScheduled = true;
      requestAnimationFrame(() => {
        render();
        renderScheduled = false;
      });
    }
  }

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;

    assistantMessage.content += decoder.decode(value, { stream: true });
    scheduleRender();
  }

  const rest = decoder.decode();
  if (rest) assistantMessage.content += rest;
  render();
}

function compress(str) {
  try {
    return LZString.compressToUTF16(str);
  } catch {
    return str;
  }
}

function decompress(str) {
  try {
    return LZString.decompressFromUTF16(str);
  } catch {
    return str;
  }
}

function loadHistory() {
  try {
    const saved = localStorage.getItem(storageKey);
    if (!saved) return [];
    const decompressed = decompress(saved);
    return Array.isArray(JSON.parse(decompressed)) ? JSON.parse(decompressed) : [];
  } catch {
    return [];
  }
}

function saveHistory() {
  try {
    const toSave = JSON.stringify(history.slice(-50));
    localStorage.setItem(storageKey, compress(toSave));
  } catch (error) {
    console.error("Error saving history:", error);
  }
}

function loadConversations() {
  try {
    const saved = localStorage.getItem("nova-conversations");
    if (!saved) return [];
    const decompressed = decompress(saved);
    return Array.isArray(JSON.parse(decompressed)) ? JSON.parse(decompressed) : [];
  } catch {
    return [];
  }
}

function saveConversations() {
  try {
    const toSave = JSON.stringify(conversations);
    localStorage.setItem("nova-conversations", compress(toSave));
  } catch (error) {
    console.error("Error saving conversations:", error);
  }
}

function createNewConversation() {
  const id = Date.now().toString(36) + Math.random().toString(36).substr(2);
  const conversation = {
    id,
    title: "Nova conversa",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString()
  };
  conversations.unshift(conversation);
  saveConversations();
  return id;
}

function updateConversationTitle(conversationId, firstMessage) {
  const conversation = conversations.find(c => c.id === conversationId);
  if (conversation && conversation.title === "Nova conversa") {
    conversation.title = firstMessage.slice(0, 30) + (firstMessage.length > 30 ? "..." : "");
    conversation.updatedAt = new Date().toISOString();
    saveConversations();
  }
}

function loadDevHistory() {
  try {
    const saved = localStorage.getItem("nova-dev-history");
    if (!saved) return [];
    const decompressed = decompress(saved);
    return Array.isArray(JSON.parse(decompressed)) ? JSON.parse(decompressed) : [];
  } catch {
    return [];
  }
}

function saveDevHistory() {
  try {
    const toSave = JSON.stringify(devHistory.slice(-50));
    localStorage.setItem("nova-dev-history", compress(toSave));
  } catch (error) {
    console.error("Error saving dev history:", error);
  }
}

function addDevHistory(action, details, status = 'success') {
  devHistory.unshift({
    id: Date.now().toString(36),
    action,
    details,
    status,
    timestamp: new Date().toISOString()
  });
  saveDevHistory();
}

function showDevApproval(action, details) {
  pendingDevAction = { action, details };
  
  let content = `<p class="warning">${details.warning || 'Esta ação requer sua aprovação.'}</p>`;
  
  if (action === 'writeFile') {
    content += `<p><strong>Arquivo:</strong> <code>${details.path}</code></p>`;
    content += `<p><strong>Conteúdo:</strong></p>`;
    content += `<pre>${escapeHtml(details.content)}</pre>`;
  } else if (action === 'executeCommand') {
    content += `<p><strong>Comando:</strong> <code>${escapeHtml(details.command)}</code></p>`;
  } else if (action === 'installDependency') {
    content += `<p><strong>Pacote:</strong> <code>${escapeHtml(details.package)}</code></p>`;
  }
  
  devApprovalContent.innerHTML = content;
  devApprovalModal.hidden = false;
}

async function executeDevAction(action, details, approved = false) {
  const endpoint = getDevEndpoint(action);
  
  try {
    const response = await fetch(`${apiBase}${endpoint}`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...details, approved })
    });
    const result = await response.json();
    
    if (result.requiresApproval) {
      showDevApproval(action, result);
      return null;
    }
    
    addDevHistory(action, details, result.ok ? 'success' : 'error');
    return result;
  } catch (error) {
    addDevHistory(action, details, 'error');
    console.error('Dev action error:', error);
    return { ok: false, error: error.message };
  }
}

function getDevEndpoint(action) {
  const endpoints = {
    writeFile: '/api/dev/file',
    executeCommand: '/api/dev/command',
    installDependency: '/api/dev/install',
    createBackup: '/api/dev/backup',
    restoreBackup: '/api/dev/restore'
  };
  return endpoints[action] || '';
}

function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

function parseDevCommand(message) {
  if (!settings.devMode) return null;
  
  const patterns = [
    {
      regex: /(?:criar|editar|modificar)\s+(?:o\s+)?arquivo\s+(.+?):\s*(.+)/is,
      action: 'writeFile',
      extract: (match) => ({ path: match[1].trim(), content: match[2].trim() })
    },
    {
      regex: /(?:executar|rodar)\s+(?:o\s+)?comando\s+(.+)/is,
      action: 'executeCommand',
      extract: (match) => ({ command: match[1].trim() })
    },
    {
      regex: /(?:instalar|adicionar)\s+(?:a\s+)?depend[êe]ncia\s+(.+)/is,
      action: 'installDependency',
      extract: (match) => ({ package: match[1].trim() })
    },
    {
      regex: /(?:listar|ver)\s+(?:os\s+)?arquivos\s+(?:do\s+)?(?:diret[óo]rio\s+)?(.*)/is,
      action: 'listFiles',
      extract: (match) => ({ path: match[1].trim() || null })
    },
    {
      regex: /(?:ler|ver)\s+(?:o\s+)?arquivo\s+(.+)/is,
      action: 'readFile',
      extract: (match) => ({ path: match[1].trim() })
    },
    {
      regex: /(?:criar|fazer)\s+(?:um\s+)?backup\s+(?:do\s+)?arquivo\s+(.+)/is,
      action: 'createBackup',
      extract: (match) => ({ path: match[1].trim() })
    }
  ];
  
  for (const pattern of patterns) {
    const match = message.match(pattern.regex);
    if (match) {
      return {
        action: pattern.action,
        details: pattern.extract(match)
      };
    }
  }
  
  return null;
}

function closeMemory() {
  memoryModal.hidden = true;
  memoryButton.focus();
}

function loadSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem(settingsKey) || "{}");
    return {
      personality: ["equilibrada", "direta", "amiga", "tecnica", "jarvis"].includes(saved.personality)
        ? saved.personality
        : "jarvis",
      mode: ["normal", "estudo", "criativo", "codigo", "rapido"].includes(saved.mode)
        ? saved.mode
        : "normal",
      memory: typeof saved.memory === "string" ? saved.memory.slice(0, 2000) : "",
      devMode: Boolean(saved.devMode)
    };
  } catch {
    return { personality: "jarvis", mode: "normal", memory: "", devMode: false };
  }
}

function saveSettings() {
  localStorage.setItem(settingsKey, JSON.stringify(settings));
}

async function loadFileProfile() {
  try {
    const response = await fetch(`${apiBase}/api/dev/profile`);
    const data = await response.json();
    if (!data.ok || !data.profile) return;

    settings.personality = data.profile.personality || settings.personality;
    settings.memory = data.profile.memory || settings.memory;
    personalitySelect.value = settings.personality;
    memoryInput.value = settings.memory;
    syncModeUI();
    saveSettings();
  } catch {
    // Keep browser settings when the profile file cannot be loaded.
  }
}

async function boot() {
  try {
    const response = await fetch(`${apiBase}/api/auth/status`, { signal: AbortSignal.timeout(10000) });
    const data = await response.json();

    if (data.protected && !data.authenticated) {
      loginMode = data.loginMode || "password";
      syncAccessUI();
      accessGate.hidden = false;
      appShell.hidden = true;
      (loginMode === "users" ? accessUsername : accessPassword).focus();
      return;
    }
  } catch (error) {
    // If auth status cannot be checked, show a warning but still try to use the app
    console.warn("Nao foi possivel verificar o status de autenticacao:", error);
  }

  showApp();
}

function showApp() {
  accessGate.hidden = true;
  appShell.hidden = false;
  loadFileProfile();
  render();
  input.focus();
}

function syncAccessUI() {
  const usesUsers = loginMode === "users";
  usernameField.hidden = !usesUsers;
  accessUsername.required = usesUsers;
  accessPassword.placeholder = usesUsers ? "Digite sua senha" : "Digite a senha";
}

function syncModeUI() {
  for (const button of modeButtons) {
    const active = button.dataset.mode === settings.mode;
    button.classList.toggle("active", active);
    button.setAttribute("aria-pressed", String(active));
  }
}

function syncDevModeUI() {
  devModeButton.classList.toggle("active", settings.devMode);
  devModeButton.setAttribute("aria-pressed", String(settings.devMode));
  document.body.classList.toggle("dev-mode", settings.devMode);
}

function applyAssistantConfig(assistantMessage) {
  const configPattern = /\[\[NOVA_CONFIG:({[\s\S]*?})\]\]/;
  const match = assistantMessage.content.match(configPattern);
  if (!match) return;

  assistantMessage.content = assistantMessage.content.replace(configPattern, "").trim();

  try {
    const config = JSON.parse(match[1]);
    const updates = [];

    if (["equilibrada", "direta", "amiga", "tecnica", "jarvis"].includes(config.personality)) {
      settings.personality = config.personality;
      personalitySelect.value = config.personality;
      updates.push(`personalidade: ${labelPersonality(config.personality)}`);
    }

    if (typeof config.memoryAppend === "string" && config.memoryAppend.trim()) {
      const addition = config.memoryAppend.trim().slice(0, 500);
      settings.memory = [settings.memory, addition].filter(Boolean).join("\n").slice(0, 2000);
      memoryInput.value = settings.memory;
      updates.push("memoria atualizada");
    }

    if (typeof config.memoryReplace === "string") {
      settings.memory = config.memoryReplace.trim().slice(0, 2000);
      memoryInput.value = settings.memory;
      updates.push("memoria substituida");
    }

    saveSettings();

    if (updates.length > 0) {
      assistantMessage.content += `\n\nConfiguracao aplicada: ${updates.join(", ")}.`;
    }
  } catch {
    assistantMessage.content += "\n\nNao consegui aplicar a configuracao automaticamente.";
  }
}

function prepareFileProfileEdit(assistantMessage) {
  const configPattern = /\[\[NOVA_PROFILE_FILE:({[\s\S]*?})\]\]/;
  const match = assistantMessage.content.match(configPattern);
  if (!match) return;

  assistantMessage.content = assistantMessage.content.replace(configPattern, "").trim();

  try {
    const config = JSON.parse(match[1]);
    const profile = {
      name: "Astra",
      personality: settings.personality,
      memory: settings.memory
    };

    if (["equilibrada", "direta", "amiga", "tecnica", "jarvis"].includes(config.personality)) {
      profile.personality = config.personality;
    }

    if (typeof config.memoryAppend === "string" && config.memoryAppend.trim()) {
      profile.memory = [profile.memory, config.memoryAppend.trim().slice(0, 500)]
        .filter(Boolean)
        .join("\n")
        .slice(0, 2000);
    }

    if (typeof config.memoryReplace === "string") {
      profile.memory = config.memoryReplace.trim().slice(0, 2000);
    }

    pendingFileProfile = profile;
    filePreview.textContent = JSON.stringify(profile, null, 2);
    fileApprovalModal.hidden = false;
  } catch {
    assistantMessage.content += "\n\nNao consegui preparar a alteracao de arquivo.";
  }
}

async function applyPendingFileProfile() {
  if (!pendingFileProfile) return;

  applyFileEditButton.disabled = true;

  try {
    const response = await fetch(`${apiBase}/api/dev/apply-profile`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        confirmed: true,
        profile: pendingFileProfile
      })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao consegui gravar o arquivo.");
    }

    settings.personality = data.profile.personality;
    settings.memory = data.profile.memory;
    personalitySelect.value = settings.personality;
    memoryInput.value = settings.memory;
    saveSettings();

    history.push({
      role: "assistant",
      content: `Arquivo seguro atualizado: ${data.file}. Backup: ${data.backup || "nao precisava"}.`
    });
    saveHistory();
    render();
    closeFileApproval();
  } catch (error) {
    history.push({
      role: "assistant",
      content: error.message || "Nao consegui gravar o arquivo com seguranca."
    });
    saveHistory();
    render();
  } finally {
    applyFileEditButton.disabled = false;
  }
}

function closeFileApproval() {
  fileApprovalModal.hidden = true;
  pendingFileProfile = null;
  filePreview.textContent = "";
  devModeButton.focus();
}

function labelPersonality(value) {
  return {
    equilibrada: "Equilibrada",
    direta: "Direta",
    amiga: "Amiga",
    tecnica: "Tecnica",
    jarvis: "Jarvis"
  }[value] || value;
}

async function copyText(text) {
  if (navigator.clipboard?.writeText) {
    await navigator.clipboard.writeText(text);
    return;
  }

  const temporary = document.createElement("textarea");
  temporary.value = text;
  temporary.style.position = "fixed";
  temporary.style.opacity = "0";
  document.body.append(temporary);
  temporary.select();
  document.execCommand("copy");
  temporary.remove();
}

function flashButton(button, text) {
  const original = button.textContent;
  button.textContent = text;
  window.setTimeout(() => {
    button.textContent = original;
  }, 1200);
}

function speakText(text) {
  if (!("speechSynthesis" in window)) return;

  window.speechSynthesis.cancel();
  const speech = new SpeechSynthesisUtterance(text.slice(0, 1200));
  speech.lang = "pt-BR";
  speech.rate = 1;
  window.speechSynthesis.speak(speech);
}

function exportConversation() {
  const format = prompt("Escolha o formato: txt, json, md, pdf");
  if (!format) return;

  const stamp = new Date().toISOString().slice(0, 10);
  let content, mimeType, filename;

  switch (format.toLowerCase()) {
    case 'json':
      content = JSON.stringify(history, null, 2);
      mimeType = 'application/json';
      filename = `conversa-astra-${stamp}.json`;
      break;
    case 'md':
      content = history.map((message) => {
        const label = message.role === "user" ? "### Você" : "### Astra";
        return `${label}\n\n${message.content}\n\n---`;
      }).join('\n');
      mimeType = 'text/markdown';
      filename = `conversa-astra-${stamp}.md`;
      break;
    case 'pdf':
      exportToPDF(stamp);
      return;
    case 'txt':
    default:
      content = history.map((message) => {
        const label = message.role === "user" ? "Voce" : "Astra";
        return `${label}: ${message.content}`;
      }).join('\n\n');
      mimeType = 'text/plain';
      filename = `conversa-astra-${stamp}.txt`;
  }

  const blob = new Blob([content], { type: `${mimeType};charset=utf-8` });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = filename;
  document.body.append(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function exportToPDF(stamp) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  
  let y = 20;
  doc.setFontSize(16);
  doc.text('Conversa com Astra', 20, y);
  y += 15;
  
  doc.setFontSize(12);
  history.forEach((message) => {
    if (y > 270) {
      doc.addPage();
      y = 20;
    }
    
    const label = message.role === "user" ? "Você:" : "Astra:";
    doc.setFont(undefined, 'bold');
    doc.text(label, 20, y);
    y += 7;
    
    doc.setFont(undefined, 'normal');
    const lines = doc.splitTextToSize(message.content, 170);
    lines.forEach((line) => {
      if (y > 270) {
        doc.addPage();
        y = 20;
      }
      doc.text(line, 20, y);
      y += 5;
    });
    y += 5;
  });
  
  doc.save(`conversa-astra-${stamp}.pdf`);
}

// WhatsApp approval system
const whatsappPanel = document.querySelector("#whatsappPanel");
const whatsappQueue = document.querySelector("#whatsappQueue");
const closeWhatsappButton = document.querySelector("#closeWhatsappButton");
const refreshWhatsappButton = document.querySelector("#refreshWhatsappButton");
const viewWhatsappLogButton = document.querySelector("#viewWhatsappLogButton");
const whatsappLogModal = document.querySelector("#whatsappLogModal");
const whatsappLogContent = document.querySelector("#whatsappLogContent");
const closeWhatsappLogButton = document.querySelector("#closeWhatsappLogButton");
const whatsappButton = document.querySelector("#whatsappButton");
const themeButton = document.querySelector("#themeButton");
const apiStatus = document.querySelector("#apiStatus");
const searchButton = document.querySelector("#searchButton");
const newConversationButton = document.querySelector("#newConversationButton");
const searchPanel = document.querySelector("#searchPanel");
const searchInput = document.querySelector("#searchInput");
const searchResults = document.querySelector("#searchResults");
const closeSearchButton = document.querySelector("#closeSearchButton");
const conversationsPanel = document.querySelector("#conversationsPanel");
const conversationsList = document.querySelector("#conversationsList");
const closeConversationsButton = document.querySelector("#closeConversationsButton");
const devApprovalModal = document.querySelector("#devApprovalModal");
const devApprovalContent = document.querySelector("#devApprovalContent");
const closeDevApprovalButton = document.querySelector("#closeDevApprovalButton");
const approveDevAction = document.querySelector("#approveDevAction");
const rejectDevAction = document.querySelector("#rejectDevAction");
const devHistoryPanel = document.querySelector("#devHistoryPanel");
const devHistoryList = document.querySelector("#devHistoryList");
const closeDevHistoryButton = document.querySelector("#closeDevHistoryButton");

let whatsappMessages = [];
let isDarkTheme = true;
let devHistory = loadDevHistory();
let pendingDevAction = null;

closeWhatsappButton.addEventListener("click", () => {
  whatsappPanel.hidden = true;
});

whatsappButton.addEventListener("click", () => {
  whatsappPanel.hidden = false;
  loadWhatsappQueue();
});

refreshWhatsappButton.addEventListener("click", loadWhatsappQueue);
viewWhatsappLogButton.addEventListener("click", loadWhatsappLog);

themeButton.addEventListener("click", toggleTheme);

searchButton.addEventListener("click", () => {
  searchPanel.hidden = false;
  searchInput.focus();
});

closeSearchButton.addEventListener("click", () => {
  searchPanel.hidden = true;
});

searchInput.addEventListener("input", () => {
  const query = searchInput.value.toLowerCase().trim();
  if (!query) {
    searchResults.innerHTML = '<p class="whatsapp-empty">Digite para buscar...</p>';
    return;
  }

  const results = history.filter((message) => 
    message.content.toLowerCase().includes(query)
  );

  if (results.length === 0) {
    searchResults.innerHTML = '<p class="whatsapp-empty">Nenhum resultado encontrado.</p>';
    return;
  }

  searchResults.innerHTML = results.map((message, index) => `
    <div class="search-result">
      <span class="search-role">${message.role === 'user' ? 'Você' : 'Astra'}:</span>
      <p class="search-content">${message.content.slice(0, 200)}${message.content.length > 200 ? '...' : ''}</p>
    </div>
  `).join('');
});

searchPanel.addEventListener("click", (event) => {
  if (event.target === searchPanel) searchPanel.hidden = true;
});

newConversationButton.addEventListener("click", () => {
  conversationsPanel.hidden = false;
  renderConversationsList();
});

closeConversationsButton.addEventListener("click", () => {
  conversationsPanel.hidden = true;
});

closeDevApprovalButton.addEventListener("click", () => {
  devApprovalModal.hidden = true;
  pendingDevAction = null;
});

approveDevAction.addEventListener("click", async () => {
  if (!pendingDevAction) return;
  const result = await executeDevAction(pendingDevAction.action, pendingDevAction.details, true);
  devApprovalModal.hidden = true;
  pendingDevAction = null;
  if (result) {
    history.push({
      role: "assistant",
      content: result.ok ? "Ação executada com sucesso." : `Erro ao executar ação: ${result.error}`
    });
    render();
  }
});

rejectDevAction.addEventListener("click", () => {
  devApprovalModal.hidden = true;
  pendingDevAction = null;
  history.push({
    role: "assistant",
    content: "Ação rejeitada pelo usuário."
  });
  render();
});

closeDevHistoryButton.addEventListener("click", () => {
  devHistoryPanel.hidden = true;
});

devHistoryPanel.addEventListener("click", (event) => {
  if (event.target === devHistoryPanel) devHistoryPanel.hidden = true;
});

conversationsPanel.addEventListener("click", (event) => {
  if (event.target === conversationsPanel) conversationsPanel.hidden = true;
});

function renderConversationsList() {
  if (conversations.length === 0) {
    conversationsList.innerHTML = '<p class="whatsapp-empty">Nenhuma conversa salva.</p>';
    return;
  }

  conversationsList.innerHTML = conversations.map((conv) => `
    <div class="conversation-item ${conv.id === currentConversationId ? 'active' : ''}" data-id="${conv.id}">
      <div class="conversation-title">${conv.title}</div>
      <div class="conversation-date">${new Date(conv.updatedAt).toLocaleDateString('pt-BR')}</div>
      <button class="delete-conversation" data-id="${conv.id}" title="Excluir">&#215;</button>
    </div>
  `).join('');

  conversationsList.querySelectorAll('.conversation-item').forEach(item => {
    item.addEventListener('click', (e) => {
      if (e.target.classList.contains('delete-conversation')) return;
      switchConversation(item.dataset.id);
    });
  });

  conversationsList.querySelectorAll('.delete-conversation').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      deleteConversation(btn.dataset.id);
    });
  });
}

function renderDevHistory() {
  if (devHistory.length === 0) {
    devHistoryList.innerHTML = '<p class="whatsapp-empty">Nenhuma ação Dev registrada.</p>';
    return;
  }

  devHistoryList.innerHTML = devHistory.map(item => `
    <div class="dev-history-item ${item.status}">
      <div class="dev-history-action">${item.action}</div>
      <div class="dev-history-details">${JSON.stringify(item.details)}</div>
      <div class="dev-history-timestamp">${new Date(item.timestamp).toLocaleString('pt-BR')}</div>
      ${item.status === 'success' ? `
        <div class="dev-history-rollback">
          <button onclick="rollbackDevAction('${item.id}')">Rollback</button>
        </div>
      ` : ''}
    </div>
  `).join('');
}

async function rollbackDevAction(id) {
  const action = devHistory.find(a => a.id === id);
  if (!action) return;

  if (action.action === 'writeFile') {
    const backupResult = await executeDevAction('createBackup', { path: action.details.path });
    if (backupResult && backupResult.ok) {
      addDevHistory('rollback', { originalId: id }, 'success');
      alert('Backup criado antes de rollback.');
    }
  }
}

function switchConversation(conversationId) {
  currentConversationId = conversationId;
  conversationsPanel.hidden = true;
  renderConversationsList();
  input.focus();
}

function deleteConversation(conversationId) {
  if (!confirm('Tem certeza que deseja excluir esta conversa?')) return;
  
  conversations = conversations.filter(c => c.id !== conversationId);
  saveConversations();
  
  if (currentConversationId === conversationId) {
    if (conversations.length > 0) {
      currentConversationId = conversations[0].id;
    } else {
      currentConversationId = createNewConversation();
    }
  }
  
  renderConversationsList();
}

async function checkApiStatus() {
  try {
    const response = await fetch(`${apiBase}/health`);
    const data = await response.json();
    apiStatus.textContent = data.ok ? "API OK" : "API Error";
    apiStatus.style.color = data.ok ? "var(--accent)" : "var(--danger)";
  } catch {
    apiStatus.textContent = "API Offline";
    apiStatus.style.color = "var(--danger)";
  }
}

function toggleTheme() {
  isDarkTheme = !isDarkTheme;
  document.documentElement.style.setProperty('--bg', isDarkTheme ? '#090b10' : '#f5f7fb');
  document.documentElement.style.setProperty('--surface', isDarkTheme ? 'rgba(17, 21, 30, 0.92)' : 'rgba(255, 255, 255, 0.92)');
  document.documentElement.style.setProperty('--ink', isDarkTheme ? '#f5f7fb' : '#1a1a2e');
  document.documentElement.style.setProperty('--muted', isDarkTheme ? '#a8b0c0' : '#6b7280');
  document.documentElement.style.colorScheme = isDarkTheme ? 'dark' : 'light';
  themeButton.querySelector('span').textContent = isDarkTheme ? '&#9728;' : '&#127769;';
}

boot();
checkApiStatus();
setInterval(checkApiStatus, 60000);

closeWhatsappLogButton.addEventListener("click", () => {
  whatsappLogModal.hidden = true;
});

whatsappLogModal.addEventListener("click", (event) => {
  if (event.target === whatsappLogModal) whatsappLogModal.hidden = false;
});

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !whatsappLogModal.hidden) whatsappLogModal.hidden = true;
});

async function loadWhatsappQueue() {
  try {
    const response = await fetch(`${apiBase}/api/whatsapp/queue`);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Nao consegui carregar a fila.");
    }

    whatsappMessages = data.queue || [];
    renderWhatsappQueue();
  } catch (error) {
    whatsappQueue.innerHTML = `<p class="whatsapp-empty">Erro ao carregar: ${error.message}</p>`;
  }
}

function renderWhatsappQueue() {
  if (whatsappMessages.length === 0) {
    whatsappQueue.innerHTML = '<p class="whatsapp-empty">Nenhuma mensagem pendente.</p>';
    return;
  }

  whatsappQueue.innerHTML = "";

  for (const message of whatsappMessages) {
    const div = document.createElement("div");
    div.className = "whatsapp-message";
    div.dataset.id = message.id;

    const header = document.createElement("div");
    header.className = "whatsapp-message-header";

    const contactDiv = document.createElement("div");
    contactDiv.className = "whatsapp-contact";
    contactDiv.textContent = message.contactName || "Contato desconhecido";

    const phoneDiv = document.createElement("div");
    phoneDiv.className = "whatsapp-phone";
    phoneDiv.textContent = message.from;

    const timeDiv = document.createElement("div");
    timeDiv.className = "whatsapp-time";
    timeDiv.textContent = new Date(message.receivedAt).toLocaleString("pt-BR");

    const contactInfo = document.createElement("div");
    contactInfo.append(contactDiv, phoneDiv, timeDiv);

    header.append(contactInfo);

    const messageContent = document.createElement("div");
    messageContent.className = "whatsapp-message-content";
    messageContent.textContent = message.message;

    const replyDiv = document.createElement("div");
    replyDiv.className = "whatsapp-reply";
    replyDiv.textContent = message.aiReply;

    const editTextarea = document.createElement("textarea");
    editTextarea.className = "whatsapp-reply-edit";
    editTextarea.rows = "3";
    editTextarea.placeholder = "Editar resposta antes de enviar...";
    editTextarea.value = message.aiReply;

    const actions = document.createElement("div");
    actions.className = "whatsapp-message-actions";

    const approveButton = document.createElement("button");
    approveButton.type = "button";
    approveButton.className = "tool-button primary";
    approveButton.textContent = "Aprovar";
    approveButton.onclick = () => approveWhatsappMessage(message.id, editTextarea.value);

    const editApproveButton = document.createElement("button");
    editApproveButton.type = "button";
    editApproveButton.className = "tool-button";
    editApproveButton.textContent = "Aprovar Editado";
    editApproveButton.onclick = () => approveWhatsappMessage(message.id, editTextarea.value);

    const cancelButton = document.createElement("button");
    cancelButton.type = "button";
    cancelButton.className = "tool-button";
    cancelButton.textContent = "Cancelar";
    cancelButton.style.color = "var(--danger)";
    cancelButton.onclick = () => cancelWhatsappMessage(message.id);

    actions.append(approveButton, editApproveButton, cancelButton);

    div.append(header, messageContent, replyDiv, editTextarea, actions);
    whatsappQueue.append(div);
  }
}

async function approveWhatsappMessage(id, reply) {
  try {
    const response = await fetch(`${apiBase}/api/whatsapp/approve`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id, reply })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao consegui aprovar a mensagem.");
    }

    loadWhatsappQueue();
  } catch (error) {
    alert(`Erro: ${error.message}`);
  }
}

async function cancelWhatsappMessage(id) {
  if (!confirm("Tem certeza que deseja cancelar este envio?")) return;

  try {
    const response = await fetch(`${apiBase}/api/whatsapp/cancel`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id })
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      throw new Error(data.error || "Nao consegui cancelar o envio.");
    }

    loadWhatsappQueue();
  } catch (error) {
    alert(`Erro: ${error.message}`);
  }
}

async function loadWhatsappLog() {
  try {
    const response = await fetch(`${apiBase}/api/whatsapp/log`);
    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.error || "Nao consegui carregar o log.");
    }

    const log = data.log || [];
    whatsappLogContent.textContent = JSON.stringify(log, null, 2) || "Nenhum registro encontrado.";
    whatsappLogModal.hidden = false;
  } catch (error) {
    whatsappLogContent.textContent = `Erro: ${error.message}`;
    whatsappLogModal.hidden = false;
  }
}
